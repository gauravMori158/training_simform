# Product-Management-System
 
1. Add product Id *
2. Add product name *
3. Add price *
4. Add image 
5. add description

(image and description is Optional)

-> product id must be unique
-> user can first add product then user is able to update product. 
